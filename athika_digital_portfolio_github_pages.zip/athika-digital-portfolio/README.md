ATHIKA DIGITAL — PORTFOLIO WEBSITE
===================================

Included:
- index.html — responsive, animated portfolio website
- README.md — setup and publishing instructions

PUBLISH FREE WITH GITHUB PAGES
1. Go to https://github.com and sign in / create a free account.
2. Click the + menu → New repository.
3. Name it: athika-digital-portfolio
4. Set visibility to Public. Create repository.
5. Click Add file → Upload files.
6. Upload index.html (you can also upload README.md).
7. Click Commit changes.
8. Open repository Settings → Pages.
9. Under Build and deployment, choose "Deploy from a branch".
10. Select branch "main" and folder "/ (root)", then Save.
11. Wait a few minutes. Your site URL should look like:
    https://YOUR-USERNAME.github.io/athika-digital-portfolio/

IMPORTANT — PERSONALISE BEFORE PUBLISHING
Open index.html in a text editor (Notepad or VS Code) and search/replace:
- YOUR_EMAIL@example.com → your real professional email (replace BOTH occurrences)
- ADD YOUR NUMBER → your WhatsApp/contact number
- Replace the six sample design cards with your real poster images and project descriptions.
- Add your tools, certifications, education and experience if applying for jobs.
- The six portfolio cards currently are illustrative placeholders, not real client work or results.

ADDING REAL POSTER IMAGES
For each work card, you can replace the <div class="mockup ...">...</div> block with:
<div class="mockup" style="padding:0;background:#eee">
  <img src="images/your-poster.jpg" alt="Description of your poster"
       style="width:100%;height:100%;object-fit:cover">
</div>
Create an "images" folder in the repository and upload your image files there. Keep file names simple, e.g. kings-tvs-poster.jpg.
You can also link directly to an image file uploaded in the repository.

NOTES
- The contact form opens the visitor's email app; it does not store submissions.
- Google Fonts are loaded online. If unavailable, fallback fonts are used.
- The website is responsive and includes scroll-reveal animation, mobile navigation and a back-to-top button.
